from django.contrib import admin

# Register your models here.

from.models import *
admin.site.register(add_cam)
admin.site.register(add_lens)
admin.site.register(user_login)
admin.site.register(admin_login)